# Kafka crash-fault demo

This is a live version of **Scenario 1 (leader crash)** from Practical 1, running on a real 3-node Kafka cluster.

A producer streams telecom session-routing events into a topic, and a consumer reads them back. Partway through the run, the script kills the broker that leads the topic's partition (`docker kill`). Kafka then detects the failure, elects a new leader and keeps serving. Later the script restarts the crashed broker, which catches up and rejoins the in-sync replicas.

## How it maps to the practical

| Practical concept | In this demo |
|---|---|
| Crash failure | `docker kill` on the leader broker (abrupt stop, no clean shutdown) |
| Heartbeat detection, hb_k = 3 | Brokers heartbeat every 1 s and are declared dead after 3 s (`KAFKA_BROKER_SESSION_TIMEOUT_MS`) |
| Leader election | Controller picks a new partition leader from the in-sync replicas (ISR) |
| Majority quorum (Config C) | 3 KRaft controllers (needs 2 of 3), topic with replication factor 3 and `min.insync.replicas=2` |
| Single node (Config A) | `--rf 1`: one copy, so the partition is offline until the broker is repaired |
| Catch-up time | Restarted broker re-syncs and rejoins the ISR |

## Requirements

- Docker Desktop (or Docker Engine with the Compose plugin)
- Python 3.9+

## Run it

```bash
docker compose up -d                 # start 3 brokers (first time pulls apache/kafka:3.9.1)
pip install -r requirements.txt

python demo.py                       # replicated: RF 3, failover in a few seconds
python demo.py --rf 1                # single replica: outage lasts until repair
```

Useful options: `--crash-at 10`, `--repair-after 30`, `--duration 60`, `--rate 20` (events/s).

Clean up with `docker compose down -v`.

## What you should see (RF 3)

```
[t=  13.4s]       Topic session-routing-rf3-a1b2: 3 replicas, min ISR 2 (like Config C)
[t=  13.4s]       Leader = broker 2, in-sync replicas (ISR) = [1, 2, 3]
[t=  23.4s] !!!   CRASH: killed broker 2 (the partition leader) -- service interrupted
[t=  26.9s] >>>   Broker 2 declared dead after missed heartbeats; new leader elected = broker 1 ...
[t=  27.1s] >>>   Service restored: writes acknowledged again (3.7s after crash)
[t=  53.4s] +++   REPAIR: restarted broker 2
[t=  58.0s] +++   Broker 2 caught up and rejoined the ISR = [1, 2, 3] ...
```

The summary at the end should show **0 lost** and **0 duplicates** (acks=all plus an idempotent producer). Failover takes a few seconds.

With `--rf 1` there is no new leader. The write outage lasts about as long as `--repair-after`, which matches the 135 s single-node outage in the report against about 4 s for the replicated configurations.

Exact times will differ on your machine. The numbers above are illustrative.

## Try next

- Kill a non-leader (`docker kill kafka3` mid-run): there is no outage, only a smaller ISR.
- Kill two brokers with RF 3: writes stop, because `min.insync.replicas=2` can no longer be met. This is the quorum availability trade-off from section 5.2.
