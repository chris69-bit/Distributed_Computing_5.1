"""
Crash-fault demo with Kafka -- a live version of Scenario 1 (leader crash).

A producer streams telecom session-routing events into a Kafka topic while a
consumer reads them back. At --crash-at seconds the broker leading the topic's
partition is killed (docker kill = abrupt crash). The script prints a timeline:

    crash -> failure detected / new leader elected -> service restored
          -> repair (docker start) -> repaired broker caught up (back in ISR)

and ends with a summary: messages sent / acked / received / lost / duplicated,
failover time and the longest outage seen by the producer and the consumer.

    python demo.py            # replication factor 3  (like Config C: 3-node quorum)
    python demo.py --rf 1     # single replica         (like Config A: single node)
"""
import argparse
import json
import logging
import subprocess
import sys
import threading
import time
import uuid

from confluent_kafka import Consumer, KafkaError, Producer
from confluent_kafka.admin import AdminClient, NewTopic

BOOTSTRAP = "localhost:19092,localhost:29092,localhost:39092"
T0 = time.monotonic()

# librdkafka logs every refused connection to the dead broker; keep the demo output clean.
_quiet = logging.getLogger("kafka-quiet")
_quiet.addHandler(logging.NullHandler())
_quiet.setLevel(logging.CRITICAL)
_quiet.propagate = False
QUIET = {"logger": _quiet, "error_cb": lambda err: None}


def now():
    return time.monotonic() - T0


def log(msg, tag="     "):
    print(f"[t={now():6.1f}s] {tag} {msg}", flush=True)


class Stats:
    def __init__(self):
        self.lock = threading.Lock()
        self.sent = self.acked = self.failed = 0
        self.acked_seqs = set()
        self.max_ack_latency = 0.0
        self.received = set()
        self.duplicates = 0
        self.last_recv = None
        self.max_gap = (0.0, 0.0, 0.0)  # (gap, from_t, to_t)
        self.crash_t = None
        self.restored_t = None  # first ack for a message sent after the crash


S = Stats()
stop_producing = threading.Event()
stop_consuming = threading.Event()


def docker(*args):
    r = subprocess.run(["docker", *args], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"docker {' '.join(args)} failed: {r.stderr.strip()}\n"
                 "Is the cluster created? Run `docker compose up -d` in this folder first.")


def partition_state(admin, topic):
    """Return (leader_id, isr_list) for partition 0; leader -1 means offline."""
    try:
        md = admin.list_topics(topic, timeout=2)
        p = md.topics[topic].partitions[0]
        return p.leader, sorted(p.isrs)
    except Exception:
        return None, []


def producer_loop(topic, rate):
    p = Producer({
        "bootstrap.servers": BOOTSTRAP,
        "acks": "all",                 # wait for all in-sync replicas
        "enable.idempotence": True,    # retries never create duplicates
        "linger.ms": 0,
        "retry.backoff.ms": 100,
        "delivery.timeout.ms": 180000, # keep retrying through the outage
        **QUIET,
    })

    def on_delivery(err, msg):
        t = now()
        body = json.loads(msg.value())
        with S.lock:
            if err:
                S.failed += 1
                return
            S.acked += 1
            S.acked_seqs.add(body["seq"])
            S.max_ack_latency = max(S.max_ack_latency, t - body["t"])
            if S.crash_t is not None and S.restored_t is None and body["t"] > S.crash_t:
                S.restored_t = t

    seq = 0
    while not stop_producing.is_set():
        event = {"seq": seq, "t": now(), "session": f"sess-{seq % 50:03d}",
                 "route": f"cell-{seq % 7}"}
        try:
            p.produce(topic, json.dumps(event).encode(), on_delivery=on_delivery)
            with S.lock:
                S.sent += 1
            seq += 1
        except BufferError:
            pass  # local queue full during the outage; try again next tick
        p.poll(0)
        time.sleep(1.0 / rate)
    p.flush(200)


def consumer_loop(topic):
    c = Consumer({
        "bootstrap.servers": BOOTSTRAP,
        "group.id": f"demo-{uuid.uuid4().hex[:6]}",
        "auto.offset.reset": "earliest",
        **QUIET,
    })
    c.subscribe([topic])
    while not stop_consuming.is_set():
        msg = c.poll(0.2)
        if msg is None or (msg.error() and msg.error().code() == KafkaError._PARTITION_EOF):
            continue
        if msg.error():
            continue
        t = now()
        seq = json.loads(msg.value())["seq"]
        with S.lock:
            if seq in S.received:
                S.duplicates += 1
            S.received.add(seq)
            if S.last_recv is not None and t - S.last_recv > S.max_gap[0]:
                S.max_gap = (t - S.last_recv, S.last_recv, t)
            S.last_recv = t
    c.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rf", type=int, default=3, choices=[1, 2, 3], help="replication factor (default 3)")
    ap.add_argument("--crash-at", type=float, default=10, help="seconds before the leader is killed")
    ap.add_argument("--repair-after", type=float, default=30, help="seconds the crashed broker stays down")
    ap.add_argument("--duration", type=float, default=60, help="total run time in seconds")
    ap.add_argument("--rate", type=float, default=20, help="events per second")
    args = ap.parse_args()

    log("Starting all three brokers (no-op if already running)...")
    docker("start", "kafka1", "kafka2", "kafka3")
    admin = AdminClient({"bootstrap.servers": BOOTSTRAP, **QUIET})
    deadline = time.time() + 60
    while True:
        try:
            if len(admin.list_topics(timeout=2).brokers) == 3:
                break
        except Exception:
            pass
        if time.time() > deadline:
            sys.exit("Cluster not ready: did you run `docker compose up -d`?")
        time.sleep(1)

    topic = f"session-routing-rf{args.rf}-{uuid.uuid4().hex[:4]}"
    min_isr = "2" if args.rf == 3 else "1"
    fut = admin.create_topics([NewTopic(topic, num_partitions=1, replication_factor=args.rf,
                                        config={"min.insync.replicas": min_isr})])
    fut[topic].result()
    leader, isr = None, []
    while leader in (None, -1):
        leader, isr = partition_state(admin, topic)
        time.sleep(0.2)

    label = {1: "single replica (like Config A)", 2: "primary-backup style (2 replicas)",
             3: "3 replicas, min ISR 2 (like Config C)"}[args.rf]
    log(f"Topic {topic}: {label}")
    log(f"Leader = broker {leader}, in-sync replicas (ISR) = {isr}")

    threading.Thread(target=consumer_loop, args=(topic,), daemon=True).start()
    threading.Thread(target=producer_loop, args=(topic, args.rate), daemon=True).start()

    crash_t = args.crash_at
    repair_t = crash_t + args.repair_after
    crashed = repaired = caught_up = False
    new_leader_t = None
    announced_offline = announced_restored = False
    next_tick = 0.0

    while now() < max(args.duration, repair_t + 5) or (repaired and not caught_up and now() < repair_t + 60):
        t = now()

        if t >= next_tick:
            with S.lock:
                log(f"sent {S.sent:5d} | acked {S.acked:5d} | received {len(S.received):5d}", tag="  .  ")
            next_tick = t + 2

        if not crashed and t >= crash_t:
            leader, isr = partition_state(admin, topic)
            victim = leader
            docker("kill", f"kafka{victim}")
            with S.lock:
                S.crash_t = now()
            crashed = True
            log(f"CRASH: killed broker {victim} (the partition leader) -- service interrupted", tag="!!!  ")

        if crashed and new_leader_t is None:
            ldr, isr = partition_state(admin, topic)
            if ldr not in (None, -1, victim):
                new_leader_t = now()
                log(f"Broker {victim} declared dead after missed heartbeats; "
                    f"new leader elected = broker {ldr}, ISR = {isr} "
                    f"({new_leader_t - S.crash_t:.1f}s after crash)", tag=">>>  ")
            elif ldr == -1 and not announced_offline:
                announced_offline = True
                log("Partition OFFLINE: no other replica can take over -- waiting for repair", tag="!!!  ")

        with S.lock:
            restored = S.restored_t
        if restored is not None and not announced_restored:
            announced_restored = True
            log(f"Service restored: writes acknowledged again "
                f"({restored - S.crash_t:.1f}s after crash)", tag=">>>  ")

        if crashed and not repaired and t >= repair_t:
            docker("start", f"kafka{victim}")
            repaired = True
            log(f"REPAIR: restarted broker {victim}", tag="+++  ")

        if repaired and not caught_up:
            ldr, isr = partition_state(admin, topic)
            if victim in isr:
                caught_up = True
                log(f"Broker {victim} caught up and rejoined the ISR = {isr} (leader = broker {ldr})", tag="+++  ")

        time.sleep(0.25)

    log("Stopping producer and draining consumer...")
    stop_producing.set()
    drain_deadline = time.time() + 30
    while time.time() < drain_deadline:
        with S.lock:
            if S.acked_seqs <= S.received and S.acked + S.failed >= S.sent:
                break
        time.sleep(0.5)
    stop_consuming.set()
    time.sleep(0.5)

    with S.lock:
        lost = len(S.acked_seqs - S.received)
        gap, g_from, g_to = S.max_gap
        print("\n" + "=" * 64)
        print(f" SUMMARY  (replication factor {args.rf})")
        print("=" * 64)
        print(f" Events sent                  : {S.sent}")
        print(f" Acknowledged by Kafka        : {S.acked}")
        print(f" Failed (gave up)             : {S.failed}")
        print(f" Received by consumer         : {len(S.received)}")
        print(f" Acked but lost               : {lost}")
        print(f" Duplicates seen by consumer  : {S.duplicates}")
        if new_leader_t:
            print(f" Failover (crash -> new leader): {new_leader_t - S.crash_t:.1f} s")
        else:
            print(f" Failover (crash -> new leader): none -- waited for repair")
        if S.restored_t:
            print(f" Write outage (crash -> 1st ack): {S.restored_t - S.crash_t:.1f} s")
        print(f" Worst producer ack latency   : {S.max_ack_latency:.1f} s")
        print(f" Longest consumer gap         : {gap:.1f} s  (t={g_from:.1f}s -> t={g_to:.1f}s)")
        print("=" * 64)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted. Restart any stopped broker with: docker start kafka1 kafka2 kafka3")
